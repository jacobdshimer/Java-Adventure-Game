For three years the Tuxemon project has been working on an open source monster catching game and on building a collection of monsters that everyone is free and open to use. 

All assets are on our wiki: https://wiki.tuxemon.org/

This is the first "set" - 154 complete tuxemon. Complete in this case means:

* 64x64 pixel front sprite
* 64x64 pixel back sprite
* Two 24x24 pixel face sprites, which when combined make a menu animation
* Names and blurbs (one- or two-sentence encyclopedia entries)

Included in the ZIP is a folder with all the sprites. There is also a saved webpage with names, blurbs, attribution information and each tuxemon's sprites. 

All contributions welcome on our forums: https://forum.tuxemon.org/

Attribution details are listed for each monster. You must attribute each monster that you use. 